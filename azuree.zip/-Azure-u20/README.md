# Azure — MCP 1.8.9

Projeto novo e separado do repositório antigo `catowner25/-Azure`. A estrutura usa Gradle, Java 8 e `src/main`; nesta etapa só existe a base do projeto e os metadados `Azure.jar`/`Azure.json`.

## Escopo combinado

Do client antigo, a única implementação que poderá ser portada é **Backtrack, ClickGUI e watermark**. Todo o restante será criado do zero. O código do client antigo não foi copiado para esta pasta.

## Estado atual

Este é um esqueleto de desenvolvimento, **ainda não é um client jogável**. Não contém código-fonte MCP/Minecraft, bibliotecas nativas, assets nem um jar proprietário do jogo. O `Azure.jar` produzido agora contém apenas as classes do projeto. O JSON de versão é um ponto de partida baseado nos metadados oficiais 1.8.9; não instale o jar de scaffold esperando iniciar o jogo até a integração da base MCP estar pronta.

A referência oficial dos metadados 1.8.9 é `https://piston-meta.mojang.com/v1/packages/d546f1707a3f2b7d034eece5ea2e311eda875787/1.8.9.json`. O jar do jogo e os assets não são incluídos nem redistribuídos por este projeto.

## Build

Use Java 8 ou uma instalação de JDK compatível com target Java 8:

```bash
./gradlew build
```

Para preparar os dois arquivos de versão no formato esperado pelo launcher:

```bash
./gradlew stageLauncherFiles
```

A tarefa grava os arquivos em `build/launcher/versions/Azure/`. O jar só se tornará executável como client depois que a base MCP 1.8.9 e o bootstrap do jogo forem integrados.

## Layout

- `src/main/java/wtf/azure/client/`: metadados e ponto inicial do client.
- `src/main/resources/version/Azure.json`: metadados de lançamento da versão.
- `libs/`: reservado a dependências locais de desenvolvimento; arquivos `.jar` ficam fora do Git.
- `build/launcher/versions/Azure/`: saída da tarefa de staging com `Azure.jar` e `Azure.json`.
