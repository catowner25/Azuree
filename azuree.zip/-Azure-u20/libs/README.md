# Dependências locais

Esta pasta fica reservada para dependências locais de desenvolvimento MCP. Nenhum jar do Minecraft/MCP é incluído no repositório.

Por padrão, o Gradle procura `libs/mcp-1.8.9.jar` apenas como classpath de compilação. Também é possível indicar outro caminho com `-PmcpJar=/caminho/local/arquivo.jar`. Jars locais são ignorados pelo Git.
