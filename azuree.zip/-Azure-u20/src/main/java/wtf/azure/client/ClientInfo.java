package wtf.azure.client;

/** Basic build metadata for the clean Azure client project. */
public final class ClientInfo {
    public static final String NAME = "Azure";
    public static final String MINECRAFT_VERSION = "1.8.9";
    public static final String CLIENT_VERSION = "0.1.0-dev";

    private ClientInfo() {
    }
}
